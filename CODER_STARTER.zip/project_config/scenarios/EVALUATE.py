import dataiku
from dataiku.scenario import Scenario

# The Scenario object is the main handle from which you initiate steps
scenario = Scenario()

# Building a dataset
scenario.build_dataset("customers_binned",build_mode='NON_RECURSIVE_FORCED_BUILD')

# Build Evaluation Store
eval_store = dataiku.ModelEvaluationStore("custom_model_eval_store")
scenario.build_evaluation_store(eval_store.get_id())
